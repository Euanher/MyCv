'use strict';


/**
 * Create user
 * This can only be done by the logged in user.
 *
 * no response value expected for this operation
 **/
exports.createUser = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Creates list of users with given input array
 *
 * no response value expected for this operation
 **/
exports.createUsersWithArrayInput = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Creates list of users with given input array
 *
 * no response value expected for this operation
 **/
exports.createUsersWithListInput = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Logs user into the system
 *
 *   The user name for login
 *   The password for login in clear text
 * no response value expected for this operation
 **/
exports.loginUser = function(,) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

