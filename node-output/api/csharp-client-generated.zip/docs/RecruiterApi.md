# IO.Swagger.Api.RecruiterApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateRecruiter**](RecruiterApi.md#createrecruiter) | **POST** /recruiter | Create recruiter
[**CreateRecruitersWithArrayInput**](RecruiterApi.md#createrecruiterswitharrayinput) | **POST** /recruiter/createWithArray | Creates list of recruiters with given input array
[**CreateRecruitersWithListInput**](RecruiterApi.md#createrecruiterswithlistinput) | **POST** /Recruiter/createWithList | Creates list of recruiters with given input array
[**GetRecruiterByName**](RecruiterApi.md#getrecruiterbyname) | **GET** /recruiter/{recruitername} | Get recruiter by recruiter name
[**LoginRecruiter**](RecruiterApi.md#loginrecruiter) | **GET** /Recruiter/createWithList | Logs recruiter into the system
[**LogoutRecruiter**](RecruiterApi.md#logoutrecruiter) | **GET** /recruiter/logout | Logs out current logged in recruiter session

<a name="createrecruiter"></a>
# **CreateRecruiter**
> void CreateRecruiter ()

Create recruiter

This can only be done by the logged in recruiter.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CreateRecruiterExample
    {
        public void main()
        {
            var apiInstance = new RecruiterApi();

            try
            {
                // Create recruiter
                apiInstance.CreateRecruiter();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RecruiterApi.CreateRecruiter: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="createrecruiterswitharrayinput"></a>
# **CreateRecruitersWithArrayInput**
> void CreateRecruitersWithArrayInput ()

Creates list of recruiters with given input array

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CreateRecruitersWithArrayInputExample
    {
        public void main()
        {
            var apiInstance = new RecruiterApi();

            try
            {
                // Creates list of recruiters with given input array
                apiInstance.CreateRecruitersWithArrayInput();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RecruiterApi.CreateRecruitersWithArrayInput: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="createrecruiterswithlistinput"></a>
# **CreateRecruitersWithListInput**
> void CreateRecruitersWithListInput ()

Creates list of recruiters with given input array

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CreateRecruitersWithListInputExample
    {
        public void main()
        {
            var apiInstance = new RecruiterApi();

            try
            {
                // Creates list of recruiters with given input array
                apiInstance.CreateRecruitersWithListInput();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RecruiterApi.CreateRecruitersWithListInput: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getrecruiterbyname"></a>
# **GetRecruiterByName**
> void GetRecruiterByName ( )

Get recruiter by recruiter name

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetRecruiterByNameExample
    {
        public void main()
        {
            var apiInstance = new RecruiterApi();
            var  = new (); //  | The name that needs to be fetched. Use recruiter1 for testing. 

            try
            {
                // Get recruiter by recruiter name
                apiInstance.GetRecruiterByName();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RecruiterApi.GetRecruiterByName: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **** | [****](.md)| The name that needs to be fetched. Use recruiter1 for testing.  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="loginrecruiter"></a>
# **LoginRecruiter**
> void LoginRecruiter ( ,  )

Logs recruiter into the system

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class LoginRecruiterExample
    {
        public void main()
        {
            var apiInstance = new RecruiterApi();
            var  = new (); //  | The recruiter name for login
            var  = new (); //  | The password for login in clear text

            try
            {
                // Logs recruiter into the system
                apiInstance.LoginRecruiter(, );
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RecruiterApi.LoginRecruiter: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **** | [****](.md)| The recruiter name for login | 
 **** | [****](.md)| The password for login in clear text | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="logoutrecruiter"></a>
# **LogoutRecruiter**
> void LogoutRecruiter ()

Logs out current logged in recruiter session

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class LogoutRecruiterExample
    {
        public void main()
        {
            var apiInstance = new RecruiterApi();

            try
            {
                // Logs out current logged in recruiter session
                apiInstance.LogoutRecruiter();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RecruiterApi.LogoutRecruiter: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
